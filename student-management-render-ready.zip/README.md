# Student Management System

Render-ready mobile-friendly Student Management System frontend.

Features: Add, View, Search, Edit and Delete students. Data is saved in browser localStorage.

IMPORTANT: This package is a static frontend, so Render Static Site can serve index.html directly. It does not execute Java/JDBC or connect to MySQL. Keep the Java MVC/JDBC source separately in GitHub if your academic requirement requires it.

Render settings:
- Service: Static Site
- Build Command: leave empty
- Publish Directory: .
- Entry file: index.html
