const KEY="student-management-data";
let students=JSON.parse(localStorage.getItem(KEY)||"null")||[
{id:1,name:"Jyothika Sri",email:"jyothika@example.com",course:"CSE"},
{id:2,name:"Rahul Kumar",email:"rahul@example.com",course:"ECE"}];

const $=id=>document.getElementById(id);
function save(){localStorage.setItem(KEY,JSON.stringify(students));}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function render(){
 const q=$("search").value.trim().toLowerCase();
 const rows=students.filter(s=>[s.name,s.email,s.course].some(v=>v.toLowerCase().includes(q)));
 $("studentTable").innerHTML=rows.map(s=>`<tr><td>${s.id}</td><td>${esc(s.name)}</td><td>${esc(s.email)}</td><td>${esc(s.course)}</td><td><div class="row-actions"><button class="edit" onclick="editStudent(${s.id})">Edit</button><button class="danger" onclick="deleteStudent(${s.id})">Delete</button></div></td></tr>`).join("");
 $("empty").style.display=rows.length?"none":"block";
 $("totalStudents").textContent=students.length;
 $("totalCourses").textContent=new Set(students.map(s=>s.course.toLowerCase())).size;
}
$("studentForm").addEventListener("submit",e=>{
 e.preventDefault();
 const id=$("studentId").value;
 const data={name:$("name").value.trim(),email:$("email").value.trim(),course:$("course").value.trim()};
 if(id){const i=students.findIndex(s=>s.id==id);if(i>=0)students[i]={...students[i],...data};}
 else students.push({id:students.length?Math.max(...students.map(s=>s.id))+1:1,...data});
 save();resetForm();render();
});
function editStudent(id){
 const s=students.find(x=>x.id===id);if(!s)return;
 $("studentId").value=s.id;$("name").value=s.name;$("email").value=s.email;$("course").value=s.course;
 $("formTitle").textContent="Edit Student";$("saveBtn").textContent="Update Student";$("cancelBtn").hidden=false;
 window.scrollTo({top:0,behavior:"smooth"});
}
function deleteStudent(id){if(confirm("Delete this student?")){students=students.filter(s=>s.id!==id);save();render();}}
function resetForm(){$("studentForm").reset();$("studentId").value="";$("formTitle").textContent="Add Student";$("saveBtn").textContent="Add Student";$("cancelBtn").hidden=true;}
$("cancelBtn").addEventListener("click",resetForm);
$("search").addEventListener("input",render);
render();